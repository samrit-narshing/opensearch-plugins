"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'elastAlertPlugin';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'Elast Alert Plugin (v4.0)';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsa0JBQWxCOztBQUNBLE1BQU1DLFdBQVcsR0FBRywyQkFBcEIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ2VsYXN0QWxlcnRQbHVnaW4nO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ0VsYXN0IEFsZXJ0IFBsdWdpbiAodjQuMCknO1xuIl19